# A DATA ANALYSIS PROJECT USING HOURLY WEATHER DATA
# Name : WILLY FERNANDO HALIM
# TP_Number : TP054663

#Dataset
getwd()
setwd("C:/Users/Asus/Desktop/assignment_tp054663")
weather <- read.csv("C:/Users/Asus/Desktop/assignment_tp054663/weatherdata.csv")
summary(weather)

#Install & load packages
install.packages("ggplot2")
install.packages("tidyverse")
library(ggplot2)
library(dplyr)
library(tidyverse)
library(lattice)
library(readr)


#Pre-processing
d1m1jfk<-filter(weather,origin=="JFK")
d1m1lga<-filter(weather,origin=="LGA")
m12jfklga <- filter(weather, month=="12" & year=="2013")
m12d1 <- filter(weather, month=="12" & year=="2013" & day=="1")

#Analysis 1 : Monthly temperature comparison at JFK and LGA Airport in 2013
ggplot(weather, aes(day, temp, colour = origin )) +
  geom_point()+
  facet_wrap(~month)+
  labs(title="Monthly temperature comparison at JFK and LGA Airport in 2013",
       x="Day", y="Temperature (°F)")


#Analysis 2:
#Icing temperature on December 2013 at JFK and LGA Airport
icing <- m12jfklga %>%
  filter(temp<35.6) %>% select(origin,day,month,year,temp,dewp)
ggplot(data = icing, aes(x = day, y = temp, group = origin, colour = temp)) +
  geom_point() +
  geom_smooth(method = "loess", size=2) +
  facet_wrap(~origin)+
  theme_minimal()+
  labs(title="Icing temperature on December at JFK and LGA Airport",
       x="Day", y="Temperature")


#Analysis 3 : Daily wind speed comparison on December at JFK and LGA Airport in December 1st 2013
ggplot(m12jfklga, aes(day, wind_speed, colour = wind_speed )) +
  geom_point()+
  facet_wrap(~origin)+
  labs(title="Daily wind speed comparison on December at JFK and LGA Airport",
       x="Day", y="Wind speed (mph)")


#Analysis 4 : Graph Illustrating wind gust distribution on December 1st 2013
hist(d1m1jfk$wind_gust, main= "Graph Illustrating wind gust distribution on December 1st 2013",
     xlab="wind gust",ylab="freq",labels = TRUE,col = c("skyblue"))
hist(d1m1lga$wind_gust,add = TRUE,col = "purple",breaks = 20,
     labels = T)


#Analysis 5:Relationship between wind speed and wind gust for each origin
windspeed <- ggplot(weather, aes(wind_speed, wind_gust,colour = origin)) +
  geom_point() +
  geom_line()+
  geom_smooth() +
  facet_wrap(~origin)+
  labs(title = "Relationship between wind speed and wind gust for each origin",
       x = "Wind Speed (mph)", y="Wind Gust (mph)")
windspeed


#Analysis 6 : The Temperature from filtered wind speed (mph) data frame related to Density
windspeed2 <- weather %>%
  filter(wind_speed >=34)%>% select(origin,time_hour,temp,wind_speed)%>%
  arrange(desc(wind_speed))
ggplot(windspeed2,aes(temp,color=origin))+geom_density(adjust=5)+
  facet_wrap(~origin)+
  labs(title = "The Temperature(F) from filtered wind speed in (mph) data frame related to Density",
       x = "Temperature(F)", y="Density")


#Analysis 7:
#Temperature(F) and dewpoint for winter season 2013
winter <- weather %>%
  filter((month =="12"|month =="1"|month =="2")) %>% select(origin,month,temp,dewp)
ggplot(winter,aes(temp,dewp,color=origin))+geom_point()+
  geom_smooth(colour = "blue",size = 2)+
  facet_wrap(~month)+
  labs(title="Temperature(F) and dewpoint for winter season",
       x="Temperature(F)", y="Dewpoint ")



#Analysis 8: Hourly Humidiy comparison in 1 December 2013
ggplot(m12d1, aes(hour, humid)) +
  geom_point() +
  geom_line() +
  geom_smooth(method = "loess") +
  facet_wrap(~origin)+
  labs(title = "Hourly Humidiy comparison in 1 December 2013",
       x = "hour", y = "humidity")

#Analysis 9: Dangerous visibility for flight at each origin in December 2013
bahayavisib <- m12jfklga %>%
  filter(visib<1.00) %>% select(origin,day,month,year,visib)
ggplot(data = bahayavisib, aes(x = day, y = visib, group = origin, colour = origin)) +
  theme(legend.position = "top") +
  geom_point() +
  geom_smooth(method = "loess") +
  facet_wrap(~origin)+
  labs(title=" Dangerous visibility for flight at each origin in December 2013",
       x="Day", y="Visibility(mile)")


#Analysis 10 : Precipitation density comparison in December 2013
ggplot(m12jfklga, aes(precip, fill = precip, colour = origin)) +
  geom_density()+
  facet_wrap(~origin)+
  labs(title = "Precipitation density comparison in December 2013",
       x = "Precipitation (inch)", y="Density")


#Analysis 11 Daily pressure level comparison in 1 December 2013
ggplot(m12jfklga, aes(day, pressure),) +
  geom_point() +
  geom_line() +
  geom_smooth(method = "loess") +
  facet_wrap(~origin)+
  labs(title = "Daily pressure level comparison in 1 December 2013 ",
       x = "day", y = "pressure (milibar)")


#Analysis 12: Frequency of High wind gust Warning in 2013
windwarn<-filter(weather, wind_gust >="45.00")

hist(windwarn$wind_gust, main= "Frequency of High wind gust Warning in 2013",
     xlab="wind gust(mph)",ylab="freq",labels = TRUE,col = c("skyblue"))
##extrafeature: density plot with jittered rug
ggplot(windwarn) +
  geom_density(aes(x = wind_gust)) +
  geom_rug(aes(x = wind_gust, y = 0), position = position_jitter(height = 0))

#Analysis 13: Excessive Humidity level at each origin in December 2013
dgrhum <- m12jfklga %>%
  filter(humid>60.00) %>% select(origin,day,month,year,humid)
ggplot(data = dgrhum, aes(x = day, y = humid, group = origin, colour = origin)) +
  theme(legend.position = "top") +
  geom_point() +
  facet_wrap(~origin)+
  labs(title="Excessive Humidity level at each origin in December 2013",
       x="Day", y="Humidity(%)")

#Analysis 14 + Extra Feature 2 : Visibility distribution for each month in 2013 at JFK
ggplot(d1m1jfk,aes(x = month, y = visib,group=month)) +
  geom_violin(fill="purple") +
  geom_point(aes(size = visib), colour = "orange", position = "jitter") +
  ggtitle ("Visibility distribution for each month in 2013 at JFK") +
  xlab("Month") +  ylab ("Visibility")

#Analyis 15 : Relationship between pressure and humidity in December 2013
ggplot(m12jfklga, aes(humid, pressure),) +
  geom_point() +
  geom_line() +
  geom_smooth(method = "loess") +
  facet_wrap(~origin)+
  labs(title = "Relationship between pressure and humidity in December 2013",
       y = "pressure (milibar)")





